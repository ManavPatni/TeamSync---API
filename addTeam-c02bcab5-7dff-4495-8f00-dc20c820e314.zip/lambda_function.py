import json
import os
import pymysql

def lambda_handler(event, context):
    # Retrieve RDS details from environment variables
    rds_host = os.getenv('RDS_HOST')
    rds_user = os.getenv('RDS_USER')
    rds_password = os.getenv('RDS_PASSWORD')
    rds_db = os.getenv('RDS_DB')

    # Establish a connection to the RDS MySQL database
    try:
        connection = pymysql.connect(host=rds_host,
                                     user=rds_user,
                                     password=rds_password,
                                     database=rds_db,
                                     cursorclass=pymysql.cursors.DictCursor)
    except pymysql.MySQLError as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Could not connect to RDS: {str(e)}")
        }

    team_id = event.get('team_id')
    team_name = event.get('team_name')
    college_name = event.get('college_name')
    city = event.get('city')
    state = event.get('state')
    participants = event.get('participants', [])  # List of participants
    
    try:
        with connection.cursor() as cursor:
            # Insert team information
            insert_team_query = """
                INSERT INTO teams (id, name, college_name, city, state) 
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(insert_team_query, (team_id, team_name, college_name, city, state))
            
            # Insert participants information
            insert_participant_query = """
                INSERT INTO participants (team_id, name, age, gender, phone_number, email_id, role) 
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            for participant in participants:
                cursor.execute(insert_participant_query, (
                    team_id,
                    participant['name'],
                    participant['age'],
                    participant['gender'],
                    participant['phone_number'],
                    participant['email_id'],
                    participant['role']
                ))
        
        # Commit changes
        connection.commit()
        
    except pymysql.MySQLError as e:
        # Rollback in case of error
        connection.rollback()
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error inserting into RDS: {str(e)}")
        }
    finally:
        # Close the connection
        connection.close()
    
    return {
        'statusCode': 200,
        'body': json.dumps("Team and participants added successfully!")
    }

