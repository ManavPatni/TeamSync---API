import os
import pymysql
import json

# Lambda function handler
def lambda_handler(event, context):
    # Retrieve environment variables for RDS connection
    rds_host = os.getenv('RDS_HOST')
    rds_user = os.getenv('RDS_USER')
    rds_password = os.getenv('RDS_PASSWORD')
    rds_db = os.getenv('RDS_DB')

    # Connect to the RDS MySQL database
    try:
        connection = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_db,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Could not connect to RDS: {str(e)}"})
        }

    try:
        with connection.cursor() as cursor:
            # Query to get team details and member attendance
            sql_query = """
                SELECT 
                    t.id, 
                    t.name as team_name, 
                    t.college_name, 
                    t.city, 
                    t.state,
                    t.isPresent,
                    t.receivedKit,
                    p.name as participant_name, 
                    p.phone_number,
                    p.email_id,
                    p.gender, 
                    p.age, 
                    p.role
                FROM 
                    teams t
                JOIN 
                    participants p 
                ON 
                    t.id = p.team_id;
            """
            cursor.execute(sql_query)
            result = cursor.fetchall()

            if not result:
                return {
                    "statusCode": 404,
                    "body": json.dumps({"error": "No data found"})
                }

            # Organize the results by team
            teams = {}
            for row in result:
                team_id = row['id']
                if team_id not in teams:
                    teams[team_id] = {
                        "team_id": row['id'],
                        "team_name": row['team_name'],
                        "college": row['college_name'],
                        "city": row['city'],
                        "state": row['state'],
                        "members": []
                    }
                
                member_details = {
                    "name": row['participant_name'],
                    "phone_number": row['phone_number'],
                    "email_id": row['email_id'],
                    "gender": row['gender'],
                    "age": row['age'],
                    "role": row['role']
                }
                teams[team_id]["members"].append(member_details)

            # Convert the teams dictionary to a list
            response = list(teams.values())

            return {
                "statusCode": 200,
                "body": response
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Query failed: {str(e)}"})
        }
    finally:
        connection.close()
