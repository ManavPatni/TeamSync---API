import os
import pymysql
import json

# Lambda function handler
def lambda_handler(event, context):
    # Retrieve environment variables for RDS connection
    rds_host = os.getenv('RDS_HOST')
    rds_user = os.getenv('RDS_USER')
    rds_password = os.getenv('RDS_PASSWORD')
    rds_db = os.getenv('RDS_DB')

    # Extract uid, name, and user_type from the input event
    uid = event.get('uid')
    name = event.get('name')
    user_type = event.get('user_type')

    # Ensure uid and user_type are provided
    if not uid or not user_type:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "uid and user_type are required"})
        }

    # Connect to the RDS MySQL database
    try:
        connection = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_db,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Could not connect to RDS: {str(e)}"})
        }

    try:
        with connection.cursor() as cursor:
            # Query to check the user in the database
            sql_query = """
                SELECT post, access_to, status 
                FROM users 
                WHERE uid = %s AND user_type = %s
            """
            cursor.execute(sql_query, (uid, user_type))
            result = cursor.fetchone()

            if result:
                # User found, return the result
                return {
                    "statusCode": 200,
                    "post": result['post'],
                    "access_to": result['access_to'],
                    "status": result['status']
                    
                }
            else:
                # User not found, insert the new user
                insert_query = """
                    INSERT INTO users (uid, full_name, user_type)
                    VALUES (%s, %s, %s)
                """
                cursor.execute(insert_query, (uid, name, user_type))
                connection.commit()

                return {
                    "statusCode": 201,
                    "body": json.dumps({"message": "New user created successfully"})
                }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Query failed: {str(e)}"})
        }
    finally:
        connection.close()
