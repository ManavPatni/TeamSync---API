import os
import pymysql
import json

# Lambda function handler
def lambda_handler(event, context):
    # Retrieve environment variables for RDS connection
    rds_host = os.getenv('RDS_HOST')
    rds_user = os.getenv('RDS_USER')
    rds_password = os.getenv('RDS_PASSWORD')
    rds_db = os.getenv('RDS_DB')

    # Extract team_uid from the input event
    team_uid = event.get('team_uid')

    # Ensure team_uid is provided
    if not team_uid:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "team_uid is required"})
        }

    # Connect to the RDS MySQL database
    try:
        connection = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_db,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Could not connect to RDS: {str(e)}"})
        }

    try:
        with connection.cursor() as cursor:
            # Query to get team details and member information
            sql_query = """
                SELECT 
                    t.name AS team_name,
                    t.college_name AS college,
                    t.city,
                    t.state,
                    p.id AS participant_id,
                    p.name AS participant_name,
                    p.age,
                    p.gender,
                    p.role,
                    p.isInRestRoom
                FROM teams t
                JOIN participants p ON t.id = p.team_id
                WHERE t.id = %s
            """
            cursor.execute(sql_query, (team_uid,))
            result = cursor.fetchall()

            if not result:
                return {
                    "statusCode": 404,
                    "body": json.dumps({"error": "No data found for the provided criteria"})
                }

            # Build the response structure
            response = {
                "team_name": result[0]['team_name'],
                "college": result[0]['college'],
                "city": result[0]['city'],
                "state": result[0]['state'],
                "details": []
            }

            # Use a dictionary to track unique participants by their ID
            unique_participants = {}

            for row in result:
                participant_id = row['participant_id']
                if participant_id not in unique_participants:
                    member_details = {
                        "name": row['participant_name'],
                        "gender": row['gender'],
                        "age": row['age'],
                        "role": row['role'],
                        "isInRestRoom": row['isInRestRoom'] if row['isInRestRoom'] is not None else 0
                    }
                    unique_participants[participant_id] = member_details

            response["details"] = list(unique_participants.values())

            return {
                "statusCode": 200,
                "body": response
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Query failed: {str(e)}"})
        }
    finally:
        connection.close()
