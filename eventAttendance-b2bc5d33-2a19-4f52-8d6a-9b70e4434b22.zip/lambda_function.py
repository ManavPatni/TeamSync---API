import os
import pymysql
import json

# Lambda function handler
def lambda_handler(event, context):
    # Retrieve environment variables for RDS connection
    rds_host = os.getenv('RDS_HOST')
    rds_user = os.getenv('RDS_USER')
    rds_password = os.getenv('RDS_PASSWORD')
    rds_db = os.getenv('RDS_DB')

    # Extract team_id and call_from from the input event
    team_id = event.get('team_id')
    call_from = event.get('call_from')

    # Ensure team_id and call_from are provided
    if not team_id or not call_from:
        return {
            "statusCode": 400,
            "error": "team_id and call_from are required"
        }

    # Connect to the RDS MySQL database
    try:
        connection = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_db,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "error": f"Could not connect to RDS: {str(e)}"
        }

    try:
        with connection.cursor() as cursor:
            # Update the user information based on call_from
            if call_from == "Attendance":
                update_query = """
                    UPDATE teams
                    SET isPresent = 1
                    WHERE id = %s
                """
                # Extract isPresent from the event
                is_present = event.get('isPresent', False)
                cursor.execute(update_query, (team_id))
            else:
                update_query = """
                    UPDATE teams
                    SET receivedKit = 1
                    WHERE id = %s
                """
                # Extract receivedKit from the event
                received_kit = event.get('receivedKit', False)
                cursor.execute(update_query, ( team_id))

            connection.commit()

            return {
                "statusCode": 200,
                "message": "Team information updated successfully"
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "error": f"Query failed: {str(e)}"
        }
    finally:
        connection.close()
