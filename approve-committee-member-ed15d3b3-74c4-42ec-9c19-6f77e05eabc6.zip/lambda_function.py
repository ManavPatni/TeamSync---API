import os
import pymysql
import json

# Lambda function handler
def lambda_handler(event, context):
    # Retrieve environment variables for RDS connection
    rds_host = os.getenv('RDS_HOST')
    rds_user = os.getenv('RDS_USER')
    rds_password = os.getenv('RDS_PASSWORD')
    rds_db = os.getenv('RDS_DB')

    # Extract uid, and user_type from the input event
    uid = event.get('uid')
    user_type = event.get('user_type')
    post = event.get('post')
    access_to = event.get('access_to')
    status = event.get('status')

    # Ensure uid is provided
    if not uid:
        return {
            "statusCode": 400,
            "error": "uid is required"
        }

    # Connect to the RDS MySQL database
    try:
        connection = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_db,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "error": f"Could not connect to RDS: {str(e)}"
        }

    try:
        with connection.cursor() as cursor:
            # Build the update query dynamically based on the provided fields
            update_fields = []
            update_values = []

            if user_type is not None:
                update_fields.append("user_type = %s")
                update_values.append(user_type)

            if post is not None:
                update_fields.append("post = %s")
                update_values.append(post)

            if access_to is not None:
                update_fields.append("access_to = %s")
                update_values.append(access_to)

            if status is not None:
                update_fields.append("status = %s")
                update_values.append(status)

            # Add the uid at the end for the WHERE clause
            update_values.append(uid)

            # Combine the fields into the update query
            update_query = f"""
                UPDATE users
                SET {', '.join(update_fields)}
                WHERE uid = %s
            """

            # Execute the update query
            cursor.execute(update_query, update_values)
            connection.commit()

            return {
                "statusCode": 200,
                "message": "User information updated successfully"
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "error": f"Query failed: {str(e)}"
        }
    finally:
        if connection:
            connection.close()
