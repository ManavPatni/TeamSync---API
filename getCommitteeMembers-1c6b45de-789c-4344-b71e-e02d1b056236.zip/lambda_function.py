import os
import pymysql
import json

# Lambda function handler
def lambda_handler(event, context):
    # Retrieve environment variables for RDS connection
    rds_host = os.getenv('RDS_HOST')
    rds_user = os.getenv('RDS_USER')
    rds_password = os.getenv('RDS_PASSWORD')
    rds_db = os.getenv('RDS_DB')

    # Connect to the RDS MySQL database
    try:
        connection = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_db,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Could not connect to RDS: {str(e)}"})
        }

    try:
        with connection.cursor() as cursor:
            # Query to get team details and member attendance
            sql_query = "SELECT * FROM users"
            cursor.execute(sql_query)
            result = cursor.fetchall()

            if not result:
                return {
                    "statusCode": 404,
                    "body": json.dumps({"error": "No data found"})
                }

            # Organize the results by team
            
            return {
                "statusCode": 200,
                "body": result
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Query failed: {str(e)}"})
        }
    finally:
        connection.close()
