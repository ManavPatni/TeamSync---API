import os
import pymysql
import json

# Lambda function handler
def lambda_handler(event, context):
    # Retrieve environment variables for RDS connection
    rds_host = os.getenv('RDS_HOST')
    rds_user = os.getenv('RDS_USER')
    rds_password = os.getenv('RDS_PASSWORD')
    rds_db = os.getenv('RDS_DB')

    # Validate environment variables
    if not all([rds_host, rds_user, rds_password, rds_db]):
        return {
            "statusCode": 500,
            "error": "RDS environment variables are not set"
        }

    # Extract team_uid and participants from the input event
    team_uid = event.get('team_uid')
    participants = event.get('participants')  # Expecting a list of dictionaries

    # Ensure team_uid and participants are provided
    if not team_uid or not participants:
        return {
            "statusCode": 400,
            "error": "team_uid and participants are required"
        }

    # Connect to the RDS MySQL database
    try:
        connection = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_db,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "error": f"Could not connect to RDS: {str(e)}"
        }

    try:
        with connection.cursor() as cursor:
            # Loop through each participant to update their rest room status
            for participant in participants:
                participant_name = participant.get('name')
                isInRestRoom = participant.get('isInRestRoom', 0)  # Default to 0 if not provided

                if not participant_name:
                    return {
                        "statusCode": 400,
                        "error": "Each participant must have a name"
                    }

                # Query to find the participant's ID based on the name and team
                participant_query = """
                    SELECT id FROM participants WHERE name = %s AND team_id = %s
                """
                cursor.execute(participant_query, (participant_name, team_uid))
                participant_result = cursor.fetchone()

                if not participant_result:
                    return {
                        "statusCode": 404,
                        "error": f"Participant {participant_name} not found in the team"
                    }

                participant_id = participant_result['id']

                # Update the rest room status for the participant
                update_query = """
                    UPDATE participants
                    SET isInRestRoom = %s
                    WHERE id = %s
                """
                cursor.execute(update_query, (isInRestRoom, participant_id))

            # Commit the transaction
            connection.commit()

            return {
                "statusCode": 200,
                "message": "Team rest room status records updated successfully"
            }

    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "error": f"SQL query failed: {str(e)}"
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "error": f"An unexpected error occurred: {str(e)}"
        }
    finally:
        connection.close()
