import os
import pymysql
import json

# Lambda function handler
def lambda_handler(event, context):
    # Retrieve environment variables for RDS connection
    rds_host = os.getenv('RDS_HOST')
    rds_user = os.getenv('RDS_USER')
    rds_password = os.getenv('RDS_PASSWORD')
    rds_db = os.getenv('RDS_DB')

    # Extract team_uid, date, meal_type, and participants from the input event
    team_uid = event.get('team_uid')
    meal_date = event.get('date')
    meal_type = event.get('meal_type')
    participants = event.get('participants')  # Expecting a list of dictionaries

    # Ensure team_uid, date, meal_type, and participants are provided
    if not team_uid or not meal_date or not meal_type or not participants:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "team_uid, date, meal_type, and participants are required"})
        }

    # Connect to the RDS MySQL database
    try:
        connection = pymysql.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            db=rds_db,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Could not connect to RDS: {str(e)}"})
        }

    try:
        with connection.cursor() as cursor:
            # Loop through each participant to update or insert their meal attendance
            for participant in participants:
                participant_name = participant.get('name')
                attended = participant.get('attended', 0)  # Default to 0 if not provided

                if not participant_name:
                    return {
                        "statusCode": 400,
                        "body": json.dumps({"error": "Each participant must have a name"})
                    }

                # Query to find the participant's ID based on the name and team
                participant_query = """
                    SELECT id FROM participants WHERE name = %s AND team_id = %s
                """
                cursor.execute(participant_query, (participant_name, team_uid))
                participant_result = cursor.fetchone()

                if not participant_result:
                    return {
                        "statusCode": 404,
                        "body": json.dumps({"error": f"Participant {participant_name} not found in the team"})
                    }

                participant_id = participant_result['id']

                # Check if a record already exists for this participant, date, and meal type
                check_query = """
                    SELECT id FROM meals WHERE participant_id = %s AND meal_date = %s AND meal_type = %s
                """
                cursor.execute(check_query, (participant_id, meal_date, meal_type))
                meal_record = cursor.fetchone()

                if meal_record:
                    # Update the existing meal record
                    update_query = """
                        UPDATE meals
                        SET attended = %s
                        WHERE id = %s
                    """
                    cursor.execute(update_query, (attended, meal_record['id']))
                else:
                    # Insert a new meal record
                    insert_query = """
                        INSERT INTO meals (participant_id, team_id, meal_date, meal_type, attended)
                        VALUES (%s, %s, %s, %s, %s)
                    """
                    cursor.execute(insert_query, (participant_id, team_uid, meal_date, meal_type, attended))

            connection.commit()

            return {
                "statusCode": 200,
                "body": json.dumps({"message": "Meal attendance records updated successfully"})
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Query failed: {str(e)}"})
        }
    finally:
        connection.close()
